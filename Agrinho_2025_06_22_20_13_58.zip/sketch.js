// Variáveis principais do jogo
let cesto;             
let frutas = [];      
let pontos = 0;         
let erros = 0;          
let gameState = "inicio"; 

function setup() {
  createCanvas(400, 600);
  cesto = new Cesto();      // Cria o cesto
  textAlign(CENTER, CENTER); // Centraliza texto
}

function draw() {
  background(135, 206, 235); // Cor do céu padrão

  if (gameState === "inicio") {
    // Tela inicial com título, instruções e botão play
    background(70, 130, 180);
    fill(255);
    textSize(48);
    text("Jogo da Colheita", width / 2, height / 3);

    textSize(24);
    text("Use ← e → para mover o cesto", width / 2, height / 2);
    text("Pegue 20 frutas para ganhar", width / 2, height / 2 + 30);
    text("Não deixe 3 frutas caírem", width / 2, height / 2 + 60);

    // Botão PLAY verde arredondado
    fill(0, 200, 0);
    rect(width / 2 - 75, height / 1.5, 150, 50, 10);
    fill(255);
    textSize(32);
    text("PLAY", width / 2, height / 1.5 + 25);

  } else if (gameState === "jogando") {
    // Tela principal do jogo — onde o jogo realmente acontece
    drawBackground();     // Desenha cenário de árvores e nuvens
    cesto.show();         // Desenha o cesto

    // A cada 60 frames (aprox 1s), adiciona nova fruta
    if (frameCount % 60 === 0) {
      frutas.push(new Fruta());
    }

    // Atualiza todas as frutas: queda, desenho e checagem de colisão
    for (let i = frutas.length - 1; i >= 0; i--) {
      frutas[i].fall();   // Faz a fruta cair
      frutas[i].show();   // Desenha a fruta

      // Se fruta caiu no chão (passou da tela), conta erro e diminui pontos
      if (frutas[i].y > height) {
        erros++;
        pontos--;
        frutas.splice(i, 1); // Remove fruta do array
        continue;
      }

      // Se a fruta foi pega pelo cesto, pontua e remove
      if (frutas[i].hits(cesto)) {
        pontos++;
        frutas.splice(i, 1);
      }
    }

    // Mostra pontos e erros na tela
    textSize(32);
    fill(0);
    textAlign(LEFT, TOP);
    text("Pontos: " + pontos, 10, 10);

    textSize(20);
    text("Erros: " + erros + " / 3", 10, 50);

    // Aumenta velocidade a cada 5 pontos (sem repetir para o mesmo nível)
    if (pontos % 5 === 0 && pontos > 0 && pontos !== ultimoNivel) {
      velocidade += 0.1;
      ultimoNivel = pontos;
    }

    cesto.move(); // Move o cesto com as setas

    // Verifica se o jogador perdeu ou ganhou, muda o estado do jogo
    if (erros >= 3 || pontos < -5) {
      gameState = "gameover";
    }
    if (pontos >= 10) {
      gameState = "vitoria";
    }

  } else if (gameState === "gameover") {
    // Tela de Game Over — aparece quando o jogador erra 3 vezes ou perde muitos pontos
    background(0, 0, 0, 200);
    fill(255, 0, 0);
    textSize(48);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2);

    textSize(24);
    fill(255);
    text("Clique para reiniciar", width / 2, height / 2 + 50);

  } else if (gameState === "vitoria") {
    // Tela de vitória — aparece quando o jogador coleta 10 frutas
    background(50, 205, 50);
    fill(255);
    textSize(48);
    textAlign(CENTER, CENTER);
    text("PARABÉNS!", width / 2, height / 2 - 30);

    textSize(28);
    text("Você coletou todas as frutas!", width / 2, height / 2 + 30);

    textSize(24);
    text("Clique para jogar novamente", width / 2, height / 2 + 70);
  }
}

// Função que detecta clique do mouse para iniciar ou reiniciar o jogo
function mousePressed() {
  if (gameState === "inicio" || gameState === "gameover" || gameState === "vitoria") {
    let bx = width / 2 - 75;
    let by = height / 1.5;
    let bw = 150;
    let bh = 50;

    // Se estiver na tela inicial, só inicia se clicar no botão PLAY
    if (gameState === "inicio") {
      if (mouseX > bx && mouseX < bx + bw && mouseY > by && mouseY < by + bh) {
        resetGame();
      }
    } else {
      // Se estiver em Game Over ou Vitória, qualquer clique reinicia o jogo
      resetGame();
    }
  }
}

// Função que reinicia o jogo, resetando variáveis
function resetGame() {
  pontos = 0;
  erros = 0;
  frutas = [];
  velocidade = 1;
  ultimoNivel = 0;
  cesto.x = width / 2;
  gameState = "jogando";
}

// Função para desenhar o cenário de fundo: árvores e nuvens
function drawBackground() {
  for (let i = 0; i < 3; i++) {
    fill(34, 139, 34);
    ellipse(50 + i * 100, height - 100, 80, 80);
    fill(139, 69, 19);
    rect(50 + i * 100 - 10, height - 50, 20, 50);
  }

  fill(255);
  ellipse(100, 50, 100, 60);
  ellipse(200, 80, 120, 70);
  ellipse(300, 60, 110, 65);
}

// Classe que representa o cesto do jogador
class Cesto {
  constructor() {
    this.x = width / 2;  // Posição horizontal inicial no centro
    this.width = 60;     // Largura do cesto
    this.height = 30;    // Altura do cesto
    this.speed = 5;      // Velocidade do movimento do cesto
  }

  // Desenha o cesto (retângulo laranja)
  show() {
    fill(255, 165, 0);
    rect(this.x, height - this.height - 10, this.width, this.height);
  }

  // Move o cesto para esquerda ou direita usando as setas
  move() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.speed;

    // Limita para que o cesto não saia da tela
    this.x = constrain(this.x, 0, width - this.width);
  }
}

// Classe que representa uma fruta que cai
class Fruta {
  constructor() {
    this.x = random(0, width);         // Posição horizontal aleatória
    this.y = 0;                        // Começa no topo da tela
    this.diameter = random(30, 50);   // Tamanho aleatório da fruta
    this.speed = random(1, 3) + velocidade; // Velocidade que aumenta conforme pontos
  }

  // Atualiza a posição vertical para simular a queda
  fall() {
    this.y += this.speed;
  }

  // Desenha a fruta como um círculo vermelho
  show() {
    fill(255, 0, 0);
    ellipse(this.x, this.y, this.diameter, this.diameter);
  }

  // Verifica se a fruta colidiu com o cesto (pegou a fruta)
  hits(cesto) {
    return (
      this.y + this.diameter / 2 > height - cesto.height - 10 && // parte inferior da fruta
      this.y - this.diameter / 2 < height &&
      this.x > cesto.x &&
      this.x < cesto.x + cesto.width
    );
  }
}



/*
Jogo da Colheita feito com p5.js
Objetivo: pegar frutas que caem com o cesto controlado pelo jogador.
Controles: setas esquerda e direita.
Tela inicial, vitória aos 10 pontos e game over com 3 erros.
Desenvolvido com auxílio do ChatGPT para implementar lógica, gráficos e estados do jogo.
*/